package com.example.mygeneguide;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class VerificaOTP extends AppCompatActivity {
    EditText inputCode1, inputCode2, inputCode3, inputCode4, inputCode5, inputCode6;
    String getotpbackend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verifica_otp);

        final Button verifybuttonclick = findViewById(R.id.buttongetotp);

        inputCode1 = findViewById(R.id.inputCode1);
        inputCode2 = findViewById(R.id.inputCode2);
        inputCode3 = findViewById(R.id.inputCode3);
        inputCode4 = findViewById(R.id.inputCode4);
        inputCode5 = findViewById(R.id.inputCode5);
        inputCode6 = findViewById(R.id.inputCode6);

        TextView textMobile = findViewById(R.id.textmobileshownumber);
        textMobile.setText(String.format(
                "+55-%s", getIntent().getStringExtra("mobile")
        ));

        getotpbackend = getIntent().getStringExtra("backendotp");

        final ProgressBar progressBarverificyotp = findViewById(R.id.progressbar_verify_otp);

        verifybuttonclick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isOtpFilled()) {
                    String entercodeotp = inputCode1.getText().toString() +
                            inputCode2.getText().toString() +
                            inputCode3.getText().toString() +
                            inputCode4.getText().toString() +
                            inputCode5.getText().toString() +
                            inputCode6.getText().toString();

                    if (getotpbackend != null) {
                        progressBarverificyotp.setVisibility(View.VISIBLE);
                        verifybuttonclick.setVisibility(View.INVISIBLE);

                        PhoneAuthCredential phoneAuthCredential = PhoneAuthProvider.getCredential(getotpbackend, entercodeotp);

                        FirebaseAuth.getInstance().signInWithCredential(phoneAuthCredential)
                                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                    @Override
                                    public void onComplete(@NonNull Task<AuthResult> task) {
                                        progressBarverificyotp.setVisibility(View.GONE);
                                        verifybuttonclick.setVisibility(View.VISIBLE);

                                        if (task.isSuccessful()) {
                                            Intent intent = new Intent(getApplicationContext(), MainActivity.class); // Abre MainActivity onde o HomeFragment pode ser exibido
                                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                            startActivity(intent);
                                        } else {
                                            Toast.makeText(VerificaOTP.this, "Insira o código correto", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });
                    } else {
                        Toast.makeText(VerificaOTP.this, "Por favor, verifique sua conexão com a internet", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(VerificaOTP.this, "Por favor, insira o código completo", Toast.LENGTH_SHORT).show();
                }
            }
        });

        setupOTPInputs();

        TextView resendlabel = findViewById(R.id.txtResetOTP);
        resendlabel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PhoneAuthProvider.getInstance().verifyPhoneNumber(
                        "+55" + getIntent().getStringExtra("mobile"),
                        60,
                        TimeUnit.SECONDS,
                        VerificaOTP.this,
                        new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                            @Override
                            public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                // Pode implementar caso precise de uma ação ao completar automaticamente
                            }

                            @Override
                            public void onVerificationFailed(@NonNull FirebaseException e) {
                                Toast.makeText(VerificaOTP.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onCodeSent(@NonNull String newbackendotp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                getotpbackend = newbackendotp;
                                Toast.makeText(VerificaOTP.this, "OTP reenviado com sucesso!", Toast.LENGTH_SHORT).show();
                            }
                        }
                );
            }
        });
    }

    private boolean isOtpFilled() {
        return !inputCode1.getText().toString().trim().isEmpty() &&
                !inputCode2.getText().toString().trim().isEmpty() &&
                !inputCode3.getText().toString().trim().isEmpty() &&
                !inputCode4.getText().toString().trim().isEmpty() &&
                !inputCode5.getText().toString().trim().isEmpty() &&
                !inputCode6.getText().toString().trim().isEmpty();
    }

    private void setupOTPInputs() {
        inputCode1.addTextChangedListener(new OTPTextWatcher(inputCode2));
        inputCode2.addTextChangedListener(new OTPTextWatcher(inputCode3));
        inputCode3.addTextChangedListener(new OTPTextWatcher(inputCode4));
        inputCode4.addTextChangedListener(new OTPTextWatcher(inputCode5));
        inputCode5.addTextChangedListener(new OTPTextWatcher(inputCode6));
    }

    private class OTPTextWatcher implements TextWatcher {
        private final EditText nextEditText;

        public OTPTextWatcher(EditText nextEditText) {
            this.nextEditText = nextEditText;
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            if (!charSequence.toString().trim().isEmpty()) {
                nextEditText.requestFocus();
            }
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    }
}
