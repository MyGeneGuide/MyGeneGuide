package com.example.mygeneguide;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

public class Inicio extends AppCompatActivity {

    private CardView btnGoogle, btnCadastrar;
    private TextView txtLogin;
    private GoogleSignInClient googleSignInClient;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);

        firebaseAuth = FirebaseAuth.getInstance();

        // Verifica se o usuário já está autenticado
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user != null) {
            // Usuário já autenticado, redireciona para o Início
            Intent intent = new Intent(Inicio.this, Menu.class);
            startActivity(intent);
            finish(); // Fecha a Activity atual para que o usuário não possa voltar
        }

        // Inicializando componentes da interface
        IniciarComponentes();

        // Configurando Google Sign-In
        configurarGoogleSignIn();

        // Configurando listeners dos botões
        configurarListeners();
    }

    private void configurarGoogleSignIn() {
        GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, googleSignInOptions);
    }

    private void configurarListeners() {
        btnGoogle.setOnClickListener(view -> signOutAndLogin());

        btnCadastrar.setOnClickListener(v -> {
            Intent intent = new Intent(Inicio.this, Cadastro.class);
            startActivity(intent);
        });

        txtLogin.setOnClickListener(v -> {
            Intent intent = new Intent(Inicio.this, Login.class);
            startActivity(intent);
        });
    }

    private void signOutAndLogin() {
        // Opcionalmente, faça o logout do usuário se necessário
        firebaseAuth.signOut();
        googleSignInClient.signOut().addOnCompleteListener(this, task -> {
            // Inicia o fluxo de login
            Intent signInIntent = googleSignInClient.getSignInIntent();
            startActivityForResult(signInIntent, 100); // Utilize um código de requisição
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100) { // Verifique o código de requisição
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            firebaseAuthWithGoogle(account.getIdToken());
        } catch (ApiException e) {
            Log.e("GoogleSignIn", "Falha no login: " + e.getStatusCode());
            Toast.makeText(Inicio.this, "Erro ao fazer login com Google", Toast.LENGTH_SHORT).show();
        }
    }

    private void firebaseAuthWithGoogle(String idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = firebaseAuth.getCurrentUser();
                        if (user != null) {
                            Log.d("GoogleSignIn", "Login bem-sucedido: " + user.getDisplayName());
                            Intent intent = new Intent(Inicio.this, Inicio_secundario.class);
                            startActivity(intent);
                            finish(); // Fecha a tela de login
                        }
                    } else {
                        Log.e("GoogleSignIn", "Erro ao fazer login com credenciais: ", task.getException());
                        Toast.makeText(Inicio.this, "Falha na autenticação", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void IniciarComponentes() {
        btnGoogle = findViewById(R.id.btnGoogle);
        btnCadastrar = findViewById(R.id.btnCadastrar);
        txtLogin = findViewById(R.id.txtLogin);
    }
}
