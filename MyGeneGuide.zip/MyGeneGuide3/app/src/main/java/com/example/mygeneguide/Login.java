package com.example.mygeneguide;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.mygeneguide.fragments.HomeFragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;

public class Login extends AppCompatActivity {
    private TextView txtCadastrar, txtCliqueAqui;
    private EditText editEmail, editSenha;
    private CardView btnLogin;
    private boolean senhaVisivel;
    String[] mensagens = {"Preencha todos os campos", "Login efetuado com sucesso"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        IniciarComponentes();

        txtCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), Cadastro.class);
                startActivity(intent);
                finish();
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String email = editEmail.getText().toString();
                String senha = editSenha.getText().toString();

                if (email.isEmpty() || senha.isEmpty()) {
                    Snackbar snackbar = Snackbar.make(view, mensagens[0], Snackbar.LENGTH_SHORT);
                    snackbar.setBackgroundTint(Color.WHITE);
                    snackbar.setTextColor(Color.BLACK);
                    snackbar.show();
                } else {
                    AutenticarUsuario(view);
                }
            }
        });

        editSenha.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {

                final int Right = 2;
                if (motionEvent.getAction() == MotionEvent.ACTION_UP) {
                    if (motionEvent.getRawX() >= editSenha.getRight() - editSenha.getCompoundDrawables()[Right].getBounds().width()) {
                        int selection = editSenha.getSelectionEnd();
                        if (senhaVisivel) {
                            editSenha.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.iconversenha, 0);
                            editSenha.setTransformationMethod(PasswordTransformationMethod.getInstance());
                            senhaVisivel = false;
                        } else {
                            editSenha.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_versenha, 0);
                            editSenha.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                            senhaVisivel = true;
                        }
                        editSenha.setSelection(selection);
                        return true;
                    }
                }

                return false;
            }
        });
    }
    private AlertDialog criarProgressDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.progressbar_dialog, null);
        builder.setView(dialogView);

// Criar e mostrar o diálogo
        AlertDialog dialog = builder.create();

        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.show();

// Ajustar as dimensões do diálogo
        WindowManager.LayoutParams layoutParams = dialog.getWindow().getAttributes();
        layoutParams.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.4); // 80% da largura da tela
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT; // altura automática
        dialog.getWindow().setAttributes(layoutParams);

        return dialog;
    }
    private void AutenticarUsuario(View view) {
        String email = editEmail.getText().toString();
        String senha = editSenha.getText().toString();

        // Mostrar o ProgressDialog
        AlertDialog progressDialog = criarProgressDialog();
        progressDialog.show();

        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                progressDialog.dismiss();

                if (task.isSuccessful()) {
                    EnviaOTP(); // Navega imediatamente para a tela de OTP
                } else {
                    String erro;
                    try {
                        throw task.getException();
                    } catch (FirebaseAuthWeakPasswordException e) {
                        erro = "Digite uma senha com no mínimo 6 caracteres";
                    } catch (FirebaseAuthUserCollisionException e) {
                        erro = "Essa conta já foi cadastrada";
                    } catch (FirebaseAuthInvalidCredentialsException e) {
                        erro = "E-mail ou senha inválidos";
                    } catch (Exception e) {
                        erro = "Erro ao logar o usuário";
                    }
                    Snackbar snackbar = Snackbar.make(view, erro, Snackbar.LENGTH_SHORT);
                    snackbar.setBackgroundTint(Color.WHITE);
                    snackbar.setTextColor(Color.BLACK);
                    snackbar.show();

                    // Limpar os campos mesmo se o cadastro falhar
                    limparCampos();
                }
            }
        });
    }
        private void limparCampos() {
            editEmail.setText("");
            editSenha.setText("");
    }

    private void EnviaOTP() {
        Intent intent = new Intent(Login.this, Menu.class);
        startActivity(intent);
    }

    private void IniciarComponentes() {
        txtCadastrar = findViewById(R.id.txtCadastrar);
        txtCliqueAqui = findViewById(R.id.txtCliqueAqui);
        editEmail = findViewById(R.id.editEmail);
        editSenha = findViewById(R.id.editSenha);
        btnLogin = findViewById(R.id.btnLogin);
        txtCliqueAqui.setOnClickListener(view -> showPasswordResetDialog());

    }

    private void showPasswordResetDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_esqueceu, null);
        builder.setView(dialogView);

        EditText emailbox = dialogView.findViewById(R.id.emailbox); // Adicione isso para referenciar o EditText de e-mail

        AlertDialog dialog = builder.create();

        // Remover o fundo escuro e definir o fundo transparente
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        dialogView.findViewById(R.id.btnEnviar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userEmail = emailbox.getText().toString();

                if (TextUtils.isEmpty(userEmail) || !Patterns.EMAIL_ADDRESS.matcher(userEmail).matches()) {
                    Toast.makeText(Login.this, "Entre com seu e-mail registrado", Toast.LENGTH_SHORT).show();
                    return;
                }

                FirebaseAuth.getInstance().sendPasswordResetEmail(userEmail).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(Login.this, "Cheque seu e-mail para redefinir sua senha", Toast.LENGTH_SHORT).show();
                            Log.d("PasswordReset", "Email enviado com sucesso para: " + userEmail);
                            dialog.dismiss();
                        } else {
                            String erro = task.getException() != null ? task.getException().getMessage() : "Falha ao enviar e-mail";
                            Toast.makeText(Login.this, "Erro: " + erro, Toast.LENGTH_SHORT).show();
                            Log.e("PasswordReset", "Erro ao enviar e-mail: ", task.getException());
                        }
                    }
                });
            }
        });

        dialogView.findViewById(R.id.btnCancelar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }
}
