package com.example.mygeneguide.fragments;

import android.content.Intent;
import android.os.Bundle;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioButton;

import com.example.mygeneguide.Questionario_Ametropia;
import com.example.mygeneguide.Questionario_Cardio;
import com.example.mygeneguide.Questionario_Diabetes;  // Certifique-se de importar a Activity correta
import com.example.mygeneguide.Questionario_Diabetes;
import com.example.mygeneguide.Questionario_rim;
import com.example.mygeneguide.R;

public class QuestioFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private String mParam1;
    private String mParam2;
    private CardView btnQuestioDiabetes, btnQuestioProbleRenal, btnQuestioPatCardio, btnQuestioAmetro;

    public QuestioFragment() {
        // Required empty public constructor
    }

    public static QuestioFragment newInstance(String param1, String param2) {
        QuestioFragment fragment = new QuestioFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_questio, container, false);

        // Inicializa o CardView
        btnQuestioDiabetes = view.findViewById(R.id.btnQuestioDiabetes);
        btnQuestioProbleRenal = view.findViewById(R.id.btnQuestioProbleRenal);
        btnQuestioPatCardio = view.findViewById(R.id.btnQuestioPatCardio);
        btnQuestioAmetro = view.findViewById(R.id.btnQuestioAmetro);

        btnQuestioDiabetes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Questionario_Diabetes.class);
                startActivity(intent);
            }
        });

        btnQuestioProbleRenal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), Questionario_rim.class);
                startActivity(intent);
            }
        });

        btnQuestioPatCardio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Questionario_Cardio.class);
                startActivity(intent);
            }
        });

        btnQuestioAmetro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), Questionario_Ametropia.class);
                startActivity(intent);
            }
        });

        return view;
    }
}
