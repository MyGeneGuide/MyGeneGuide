package com.example.mygeneguide;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.view.WindowManager;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.mygeneguide.fragments.QuestioFragment;

import org.w3c.dom.Text;

public class Questionario_Diabetes extends AppCompatActivity {

    RadioGroup ageGroup, maleWaistGroup, femaleWaistGroup, imcgroup, physicalActivityGroup, dietGroup, medicationGroup, glucoseGroup, familyHistoryGroup;
    Button calculateButton, cancelButton;
    TextView txtTotalIMC, questao3TextView, questao4TextView;
    CardView btnCalcularIMC;
    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_questionario_diabetes);

        // Inicializando os componentes
        RadioButton ageBelow45 = findViewById(R.id.ageBelow45);
        ageBelow45.setButtonTintList(ColorStateList.valueOf(Color.rgb(239,156,18)));
        RadioButton masculinoRadioButton = findViewById(R.id.masculino);
        RadioButton femininoRadioButton = findViewById(R.id.feminino);
        maleWaistGroup = findViewById(R.id.maleWaistGroup);
        femaleWaistGroup = findViewById(R.id.femaleWaistGroup);
        questao3TextView = findViewById(R.id.Questao3);
        questao4TextView = findViewById(R.id.Questao4);

        // Configurar a visibilidade com base na seleção de gênero
        masculinoRadioButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                maleWaistGroup.setVisibility(View.VISIBLE);
                questao3TextView.setVisibility(View.VISIBLE);
                femaleWaistGroup.setVisibility(View.GONE);
                questao4TextView.setVisibility(View.GONE);
            }
        });

        femininoRadioButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                femaleWaistGroup.setVisibility(View.VISIBLE);
                questao4TextView.setVisibility(View.VISIBLE);
                maleWaistGroup.setVisibility(View.GONE);
                questao3TextView.setVisibility(View.GONE);
            }
        });

        ageGroup = findViewById(R.id.ageGroup);
        physicalActivityGroup = findViewById(R.id.physicalActivityGroup);
        imcgroup = findViewById(R.id.imcgroup);
        dietGroup = findViewById(R.id.dietGroup);
        medicationGroup = findViewById(R.id.medicationGroup);
        glucoseGroup = findViewById(R.id.glucoseGroup);
        familyHistoryGroup = findViewById(R.id.familyHistoryGroup);

        calculateButton = findViewById(R.id.calculateButton);
        cancelButton = findViewById(R.id.cancelButton);
        btnCalcularIMC = findViewById(R.id.btnCalcularIMC);
        txtTotalIMC = findViewById(R.id.txtTotalIMC);

        // Listener do botão para calcular o risco
        calculateButton.setOnClickListener(v -> calculateRisk());

        cancelButton.setOnClickListener(view -> {
            Intent intent = new Intent(getApplication(), QuestioFragment.class);
            startActivity(intent);
            finish();
        });

        // Listener do botão para abrir o diálogo de cálculo de IMC
        btnCalcularIMC.setOnClickListener(v -> showIMCCalculatorDialog());

    }

    private void showIMCCalculatorDialog() {
        // Inflate o layout do diálogo personalizado
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_calculo_imc, null);

        // Inicialize os campos do diálogo
        EditText inputWeight = dialogView.findViewById(R.id.input_weight);
        EditText inputHeight = dialogView.findViewById(R.id.input_height);
        TextView txtResultadoIMC = dialogView.findViewById(R.id.txtResultadoIMC);

        ImageView btnCloseAlert = dialogView.findViewById(R.id.btn_closeAlert); // Botão de fechar

        // Cria o AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        builder.setCancelable(true);

        AlertDialog dialog = builder.create();

        // Configura o botão Salvar
        Button btnSave = dialogView.findViewById(R.id.btn_save);
        btnSave.setOnClickListener(v -> {
            // Pega os valores de peso e altura
            String weightStr = inputWeight.getText().toString();
            String heightStr = inputHeight.getText().toString();

            if (!weightStr.isEmpty() && !heightStr.isEmpty()) {
                double weight = Double.parseDouble(weightStr);
                double height = Double.parseDouble(heightStr) / 100; // Converte cm para metros

                // Calcula o IMC
                double imc = weight / (height * height);
                String imcResult;

                // Classificação do IMC
                if (imc < 18.5) {
                    imcResult = "Baixo peso";
                } else if (imc < 25) {
                    imcResult = "Normal ou Eutrófico";
                } else if (imc < 30) {
                    imcResult = "Sobrepeso";
                } else if (imc < 35) {
                    imcResult = "Obesidade I";
                } else if (imc < 40) {
                    imcResult = "Obesidade II";
                } else {
                    imcResult = "Obesidade III";
                }

                // Exibe o resultado do IMC
                txtResultadoIMC.setText(String.format("IMC: %.2f - %s", imc, imcResult));

                txtTotalIMC.setVisibility(View.VISIBLE);
                txtTotalIMC.setText(String.format("IMC: %.2f - %s", imc, imcResult));
            } else {
                txtResultadoIMC.setText("Por favor, insira peso e altura");
            }

        });

        // Configura o botão de fechar para encerrar o diálogo
        btnCloseAlert.setOnClickListener(v -> dialog.dismiss());

        // Exibe o diálogo
        dialog.show();
    }
    private void calculateRisk() {
        score = 0;  // Resetar o score

        // Verificar qual opção foi selecionada para cada pergunta e somar o score correspondente

        // Questão 1: Idade
        int ageId = ageGroup.getCheckedRadioButtonId();
        if (ageId == R.id.ageBelow45) score += 0;
        else if (ageId == R.id.age45to54) score += 2;
        else if (ageId == R.id.age55to64) score += 3;
        else if (ageId == R.id.ageAbove64) score += 4;

        // Somar circunferência de cintura apenas para o gênero selecionado
        if (maleWaistGroup.getVisibility() == View.VISIBLE) {
            // Somente a circunferência masculina será considerada
            int maleWaistId = maleWaistGroup.getCheckedRadioButtonId();
            if (maleWaistId == R.id.menos94) score += 0;
            else if (maleWaistId == R.id.c94a102) score += 3;
            else if (maleWaistId == R.id.mais102) score += 4;
        } else if (femaleWaistGroup.getVisibility() == View.VISIBLE) {
            // Somente a circunferência feminina será considerada
            int femaleWaistId = femaleWaistGroup.getCheckedRadioButtonId();
            if (femaleWaistId == R.id.menos80) score += 0;
            else if (femaleWaistId == R.id.c80a88) score += 3;
            else if (femaleWaistId == R.id.mais88) score += 4;
        }

        // Questão 3: IMC
        int imcgroupId = imcgroup.getCheckedRadioButtonId();
        if (imcgroupId == R.id.imcBelow25) score += 1;
        else if (imcgroupId == R.id.imc25to30) score += 2;
        else if (imcgroupId == R.id.imcAbove30) score += 4;

        // Questão 4: Atividade Física
        int physicalActivityId = physicalActivityGroup.getCheckedRadioButtonId();
        if (physicalActivityId == R.id.physicalYes) score += 0;
        else if (physicalActivityId == R.id.physicalNo) score += 2;

        // Questão 5: Alimentação
        int dietId = dietGroup.getCheckedRadioButtonId();
        if (dietId == R.id.dietEveryday) score += 0;
        else if (dietId == R.id.dietNotEveryday) score += 1;

        // Questão 6: Medicação para pressão alta
        int medicationId = medicationGroup.getCheckedRadioButtonId();
        if (medicationId == R.id.medicationNo) score += 0;
        else if (medicationId == R.id.medicationYes) score += 2;

        // Questão 7: Glicemia alta
        int glucoseId = glucoseGroup.getCheckedRadioButtonId();
        if (glucoseId == R.id.glucoseNo) score += 0;
        else if (glucoseId == R.id.glucoseYes) score += 5;

        // Questão 8: Histórico familiar de diabetes
        int familyHistoryId = familyHistoryGroup.getCheckedRadioButtonId();
        if (familyHistoryId == R.id.familyFirstDegree) score += 3;
        else if (familyHistoryId == R.id.familyImmediate) score += 5;

        // Gerar mensagem de resultado
        String resultMessage = "Resultado final: " + score + " de 31 \n";
        if (score < 8) {
            resultMessage += "Baixo risco";
        } else if (score >= 8 && score <= 12) {
            resultMessage += "Risco levemente elevado";
        } else if (score >= 13 && score <= 19) {
            resultMessage += "Risco moderado";
        } else if (score >= 20 && score <= 26) {
            resultMessage += "Risco alto";
        } else if (score > 26) {
            resultMessage += "Risco muito alto";
        }

        // Exibir o resultado em um AlertDialog
        showResultDialog(resultMessage);
    }
    private void showResultDialog(String resultMessage) {
        // Inflar o layout personalizado
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_result, null);

        // Inicializar os componentes do layout do dialog
        TextView resultTextView = dialogView.findViewById(R.id.tv_result_message);
        Button okButton = dialogView.findViewById(R.id.btn_ok);

        // Definir o texto do resultado
        resultTextView.setText(resultMessage);

        // Criar o AlertDialog
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setView(dialogView);

        // Criar o AlertDialog
        AlertDialog alertDialog = dialogBuilder.create();

        // Remover o fundo escuro
        if (alertDialog.getWindow() != null) {
            alertDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        // Exibir o AlertDialog
        alertDialog.show();

        // Ajustar a largura do AlertDialog
        if (alertDialog.getWindow() != null) {
            alertDialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.85), // largura 85% da tela
                    WindowManager.LayoutParams.WRAP_CONTENT); // altura ajustada automaticamente
        }

        // Listener para fechar o AlertDialog ao clicar no botão "OK"
        okButton.setOnClickListener(v -> alertDialog.dismiss());
    }
}
