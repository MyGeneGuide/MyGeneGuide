package com.example.mygeneguide;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class EnviaOTP extends AppCompatActivity {

    private static final String TAG = "EnviaOTP";

    private EditText enternumber;
    private Button getotpbutton;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_envia_otp);

        // Inicialização de componentes
        enternumber = findViewById(R.id.inputMobile);
        getotpbutton = findViewById(R.id.buttonGetOTP);
        progressBar = findViewById(R.id.progressbar_sending_otp);

        // Esconder o ProgressBar inicialmente
        progressBar.setVisibility(View.INVISIBLE);

        getotpbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mobileNumber = enternumber.getText().toString().trim();

                if (validatePhoneNumber(mobileNumber)) {
                    progressBar.setVisibility(View.VISIBLE);
                    getotpbutton.setVisibility(View.INVISIBLE);

                    Log.d(TAG, "Iniciando verificação OTP para o número: +55" + mobileNumber);

                    PhoneAuthProvider.getInstance().verifyPhoneNumber(
                            "+55" + mobileNumber,
                            60,
                            TimeUnit.SECONDS,
                            EnviaOTP.this,
                            new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                                @Override
                                public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                    // Se a verificação for concluída automaticamente
                                    progressBar.setVisibility(View.GONE);
                                    getotpbutton.setVisibility(View.VISIBLE);
                                    Log.d(TAG, "Verificação OTP concluída automaticamente.");

                                    // Redirecionar para VerificaOTP
                                    navigateToVerificaOTP(mobileNumber, null);
                                }

                                @Override
                                public void onVerificationFailed(@NonNull FirebaseException e) {
                                    // Em caso de falha
                                    progressBar.setVisibility(View.GONE);
                                    getotpbutton.setVisibility(View.VISIBLE);
                                    Toast.makeText(EnviaOTP.this, "Falha na verificação: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                    Log.e(TAG, "Falha na verificação OTP: " + e.getMessage());
                                }

                                @Override
                                public void onCodeSent(@NonNull String backendotp, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                    // Quando o código OTP é enviado
                                    progressBar.setVisibility(View.GONE);
                                    getotpbutton.setVisibility(View.VISIBLE);
                                    Log.d(TAG, "Código OTP enviado: " + backendotp);

                                    // Redirecionar para VerificaOTP com o código backendotp
                                    navigateToVerificaOTP(mobileNumber, backendotp);
                                }
                            }
                    );
                }
            }
        });
    }

    /**
     * Valida o número de telefone inserido pelo usuário.
     * @param mobileNumber Número de telefone
     * @return true se o número for válido; caso contrário, false
     */
    private boolean validatePhoneNumber(String mobileNumber) {
        if (mobileNumber.isEmpty()) {
            Toast.makeText(EnviaOTP.this, "Insira o número de telefone", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (mobileNumber.length() != 11) { // Ajuste conforme o seu formato esperado
            Toast.makeText(EnviaOTP.this, "Por favor, insira um número válido com 9 dígitos", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    /**
     * Redireciona para a atividade de verificação OTP, passando o número de telefone e o backendotp.
     * @param mobileNumber Número de telefone
     * @param backendotp Código OTP enviado pelo backend (pode ser null se a verificação for automática)
     */
    private void navigateToVerificaOTP(String mobileNumber, String backendotp) {
        Intent intent = new Intent(EnviaOTP.this, VerificaOTP.class);
        intent.putExtra("mobile", mobileNumber);
        if (backendotp != null) {
            intent.putExtra("backendotp", backendotp);
        }
        startActivity(intent);
    }
}
