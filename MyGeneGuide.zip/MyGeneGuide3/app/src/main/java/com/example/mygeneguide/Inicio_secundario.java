package com.example.mygeneguide;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

public class Inicio_secundario extends AppCompatActivity {

    private CardView btnGoogle, btnCadastrar;
    private TextView txtLogin;
    private GoogleSignInClient googleSignInClient;
    private FirebaseAuth firebaseAuth;

    // Novo launcher para resultados de atividades
    private final ActivityResultLauncher<Intent> googleSignInLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    Intent data = result.getData();
                    Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
                    try {
                        GoogleSignInAccount account = task.getResult(ApiException.class);
                        firebaseAuthWithGoogle(account.getIdToken());
                    } catch (ApiException e) {
                        Log.e("GoogleSignIn", "Falha no login: " + e.getStatusCode());
                        Toast.makeText(Inicio_secundario.this, "Erro ao fazer login com Google", Toast.LENGTH_SHORT).show();
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio_secundario);

        firebaseAuth = FirebaseAuth.getInstance();

        // Verifica se o usuário já está autenticado
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if (user != null) {
            // Usuário já autenticado, redireciona para o Menu
            Intent intent = new Intent(Inicio_secundario.this, Menu.class); // Alterado para Menu.class
            startActivity(intent);
            finish(); // Fecha a Activity atual para que o usuário não possa voltar
        }

        // Inicializando componentes da interface
        IniciarComponentes();

        // Configurando Google Sign-In
        configurarGoogleSignIn();

        // Configurando listeners dos botões
        configurarListeners();
    }

    private void configurarGoogleSignIn() {
        GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id)) // Certifique-se de que este ID esteja correto
                .requestEmail()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, googleSignInOptions);
    }

    private void configurarListeners() {
        btnGoogle.setOnClickListener(view -> signOutAndLogin());

        btnCadastrar.setOnClickListener(v -> {
            Intent intent = new Intent(Inicio_secundario.this, Cadastro.class);
            startActivity(intent);
        });

        txtLogin.setOnClickListener(v -> {
            Intent intent = new Intent(Inicio_secundario.this, Login.class);
            startActivity(intent);
        });
    }

    private void signOutAndLogin() {
        firebaseAuth.signOut();
        googleSignInClient.signOut().addOnCompleteListener(this, task -> {
            Intent signInIntent = googleSignInClient.getSignInIntent();
            googleSignInLauncher.launch(signInIntent); // Utilizando o launcher ao invés de startActivityForResult
        });
    }

    private void firebaseAuthWithGoogle(String idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            FirebaseUser user = firebaseAuth.getCurrentUser();
                            if (user != null) {
                                Log.d("GoogleSignIn", "Login bem-sucedido: " + user.getDisplayName());
                                Intent intent = new Intent(Inicio_secundario.this, Menu.class);
                                startActivity(intent);
                                finish(); // Fecha a tela de login
                            }
                        } else {
                            Log.e("GoogleSignIn", "Erro ao fazer login com credenciais: ", task.getException());
                            Toast.makeText(Inicio_secundario.this, "Falha na autenticação", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void IniciarComponentes() {
        btnGoogle = findViewById(R.id.btnGoogle);
        btnCadastrar = findViewById(R.id.btnCadastrar);
        txtLogin = findViewById(R.id.txtLogin);
    }
}
