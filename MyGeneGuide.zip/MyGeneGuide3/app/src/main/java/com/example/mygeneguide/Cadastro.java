package com.example.mygeneguide;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Cadastro extends AppCompatActivity {
    private EditText editNome, editEmail, editSenha, editConfSenha;
    private CardView btnCadastrar;
    private ImageView btnGoogle;
    private boolean senhaVisivel;
    private FirebaseAuth firebaseAuth;
    private GoogleSignInClient googleSignInClient;
    String[] mensagens = {"Preencha todos os campos", "Cadastro realizado com sucesso"};
    String usuarioID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_cadastro);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN); // ou SOFT_INPUT_ADJUST_PAN

        IniciarComponentes();
        firebaseAuth = FirebaseAuth.getInstance();
        configurarGoogleSignIn();

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String nome = editNome.getText().toString();
                String email = editEmail.getText().toString();
                String senha = editSenha.getText().toString();
                String confsenha = editConfSenha.getText().toString();

                if (nome.isEmpty() || email.isEmpty() || senha.isEmpty() || confsenha.isEmpty()) {
                    Snackbar snackbar = Snackbar.make(view, mensagens[0], Snackbar.LENGTH_SHORT);
                    snackbar.setBackgroundTint(Color.WHITE);
                    snackbar.setTextColor(Color.BLACK);
                    snackbar.show();
                } else {
                    CadastrarUsuario(view);
                }
            }
        });

        btnGoogle.setOnClickListener(view -> {
            Intent signInIntent = googleSignInClient.getSignInIntent();
            startActivityForResult(signInIntent, 100); // Utilize o código de requisição adequado
        });
    }
    private AlertDialog criarProgressDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.progressbar_dialog, null);
        builder.setView(dialogView);

// Criar e mostrar o diálogo
        AlertDialog dialog = builder.create();

        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.show();

// Ajustar as dimensões do diálogo
        WindowManager.LayoutParams layoutParams = dialog.getWindow().getAttributes();
        layoutParams.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.4); // 80% da largura da tela
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT; // altura automática
        dialog.getWindow().setAttributes(layoutParams);

        return dialog;
    }

    private void mostrarDialogoSucesso() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        // Infla o layout personalizado
        View view = getLayoutInflater().inflate(R.layout.dialog_cadastro_sucesso, null);
        builder.setView(view);

        AlertDialog dialog = builder.create();

        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        // Configura o botão OK
        Button btnOk = view.findViewById(R.id.btnOk);
        btnOk.setOnClickListener(v -> {
            dialog.dismiss(); // Fecha o diálogo ao clicar no botão
        });

        dialog.show(); // Mostra o diálogo

        // Ajustar as dimensões do diálogo
        WindowManager.LayoutParams layoutParams = dialog.getWindow().getAttributes();
        layoutParams.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.8); // 80% da largura da tela
        layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT; // altura automática
        dialog.getWindow().setAttributes(layoutParams);
    }
    private void CadastrarUsuario(View view) {
        String email = editEmail.getText().toString();
        String senha = editSenha.getText().toString();

        // Mostrar o ProgressDialog
        AlertDialog progressDialog = criarProgressDialog();
        progressDialog.show();

        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, senha)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        // Fechar o ProgressDialog
                        progressDialog.dismiss();

                        if (task.isSuccessful()) {
                            SalvarDadosUsuario();
                            mostrarDialogoSucesso(); // Chama o AlertDialog de sucesso

                            // Limpar os campos após o cadastro bem-sucedido
                            limparCampos();
                        } else {
                            String erro;
                            try {
                                throw task.getException();
                            } catch (FirebaseAuthWeakPasswordException e) {
                                erro = "Digite uma senha com no mínimo 6 caracteres";
                            } catch (FirebaseAuthUserCollisionException e) {
                                erro = "Essa conta já foi cadastrada";
                            } catch (FirebaseAuthInvalidCredentialsException e) {
                                erro = "E-mail inválido";
                            } catch (Exception e) {
                                erro = "Erro ao cadastrar usuário";
                            }
                            Snackbar snackbar = Snackbar.make(view, erro, Snackbar.LENGTH_SHORT);
                            snackbar.setBackgroundTint(Color.WHITE);
                            snackbar.setTextColor(Color.BLACK);
                            snackbar.show();

                            // Limpar os campos mesmo se o cadastro falhar
                            limparCampos();
                        }
                    }
                });
    }

    private void limparCampos() {
        editNome.setText("");
        editEmail.setText("");
        editSenha.setText("");
        editConfSenha.setText("");
    }


    private void SalvarDadosUsuario() {
        String nome = editNome.getText().toString();

        FirebaseFirestore db = FirebaseFirestore.getInstance();

        Map<String, Object> usuarios = new HashMap<>();
        usuarios.put("nome", nome);

        usuarioID = FirebaseAuth.getInstance().getCurrentUser().getUid();

        DocumentReference documentReference = db.collection("Usuarios").document(usuarioID);
        documentReference.set(usuarios).addOnSuccessListener(unused -> Log.d("db", "Sucesso ao salvar os dados"))
                .addOnFailureListener(e -> Log.d("db_error", "Erro ao salvar os dados: " + e.toString()));
    }

    private void IniciarComponentes() {
        editNome = findViewById(R.id.editNome);
        editEmail = findViewById(R.id.editEmail);
        editSenha = findViewById(R.id.editSenha);
        editConfSenha = findViewById(R.id.editConfSenha);
        btnCadastrar = findViewById(R.id.btnCadastrar);
        btnGoogle = findViewById(R.id.btnGoogle);

        configurarVisibilidadeSenha(editSenha);
        configurarVisibilidadeSenha(editConfSenha);
    }

    private void configurarVisibilidadeSenha(EditText editText) {
        editText.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                final int Right = 2;
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    if (event.getRawX() >= editText.getRight() - editText.getCompoundDrawables()[Right].getBounds().width()) {
                        int selection = editText.getSelectionEnd();
                        if (senhaVisivel) {
                            editText.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.iconversenha, 0);
                            editText.setTransformationMethod(PasswordTransformationMethod.getInstance());
                            senhaVisivel = false;
                        } else {
                            editText.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_versenha, 0);
                            editText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                            senhaVisivel = true;
                        }
                        editText.setSelection(selection);
                        return true;
                    }
                }
                return false;
            }
        });
    }

    private void configurarGoogleSignIn() {
        GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        googleSignInClient = GoogleSignIn.getClient(this, googleSignInOptions);

        // Para garantir que a tela de seleção de conta seja sempre exibida
        googleSignInClient.signOut();  // Desfaz qualquer login anterior
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 100) { // Verifique o código de requisição
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                GoogleSignInAccount account = task.getResult(ApiException.class);
                firebaseAuthWithGoogle(account.getIdToken());
            } catch (ApiException e) {
                Log.e("GoogleSignIn", "Erro ao fazer login: " + e.getMessage());
                Toast.makeText(Cadastro.this, "Erro ao fazer login com Google", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void firebaseAuthWithGoogle(String idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        firebaseAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = firebaseAuth.getCurrentUser();
                        if (user != null) {
                            Log.d("GoogleSignIn", "Login bem-sucedido: " + user.getDisplayName());
                            Intent intent = new Intent(Cadastro.this, Menu.class);
                            startActivity(intent);
                            finish(); // Fecha a tela de login
                        }
                    } else {
                        // Tratamento de erros de autenticação com Google
                        String erro = "";
                        try {
                            throw task.getException();
                        } catch (FirebaseAuthUserCollisionException e) {
                            erro = "Essa conta já está associada a outro método de login.";
                        } catch (Exception e) {
                            erro = "Falha na autenticação com Google.";
                            Log.e("GoogleSignIn", "Erro: ", e);
                        }
                        Toast.makeText(Cadastro.this, erro, Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
