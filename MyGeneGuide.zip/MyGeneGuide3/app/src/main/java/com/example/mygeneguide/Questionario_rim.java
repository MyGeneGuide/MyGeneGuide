package com.example.mygeneguide;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.mygeneguide.fragments.QuestioFragment;

public class Questionario_rim extends AppCompatActivity {

    RadioGroup pressaoGroup, physicalActivityGroup, inchacoGroup, aguaGroup, proteinaGroup, smokerGroupRim, familyHistoryGroup, doencaCardiGroup, medicamentoGroup;
    Button calculateButton, cancelButton;
    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_questionario_rim);

        pressaoGroup = findViewById(R.id.pressaoGroup);
        physicalActivityGroup = findViewById(R.id.physicalActivityGroup);
        inchacoGroup = findViewById(R.id.inchacoGroup);
        aguaGroup = findViewById(R.id.aguaGroup);
        proteinaGroup = findViewById(R.id.proteinaGroup);
        smokerGroupRim = findViewById(R.id.smokerGroupRim);
        familyHistoryGroup = findViewById(R.id.familyHistoryGroup);
        doencaCardiGroup = findViewById(R.id.doencaCardiGroup);
        medicamentoGroup = findViewById(R.id.medicamentoGroup);

        calculateButton = findViewById(R.id.calculateButton);
        cancelButton = findViewById(R.id.cancelButton);

        // Listener do botão para calcular o risco
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateRisk();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplication(), QuestioFragment.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void calculateRisk() {
        score = 0;  // Resetar o score

        // Verificar qual opção foi selecionada para cada pergunta e somar o score correspondente

        // Questão 1: Idade
        int pressaoId = pressaoGroup.getCheckedRadioButtonId();
        if (pressaoId == R.id.pressaoNo) score += 0;
        else if (pressaoId == R.id.pressaoYes) score += 3;

        // Questão 2: Atividade Física
        int physicalActivityId = physicalActivityGroup.getCheckedRadioButtonId();
        if (physicalActivityId == R.id.physicalYes) score += 0;
        else if (physicalActivityId == R.id.physicalNo) score += 2;

        // Questão 3: Alimentação
        int inchacoId = inchacoGroup.getCheckedRadioButtonId();
        if (inchacoId == R.id.inchacoNo) score += 0;
        else if (inchacoId == R.id.inchacoYes) score += 4;

        // Questão 4: Medicação para pressão alta
        int aguaId = aguaGroup.getCheckedRadioButtonId();
        if (aguaId == R.id.aguaYes) score += 0;
        else if (aguaId == R.id.aguaNo) score += 2;

        // Questão 5: Glicemia alta
        int proteinaId = proteinaGroup.getCheckedRadioButtonId();
        if (proteinaId == R.id.proteinaNo) score += 0;
        else if (proteinaId == R.id.proteinaYes) score += 3;

        // Questão 6: Fumo
        int smokerId = smokerGroupRim.getCheckedRadioButtonId();
        if (smokerId == R.id.smokerNoRim) score += 0;
        else if(smokerId == R.id.smokerYesRim) score += 2;

        // Questão 7: Histórico familiar de diabetes
        int familyHistoryId = familyHistoryGroup.getCheckedRadioButtonId();
        if (familyHistoryId == R.id.familyNo) score += 0;
        else if (familyHistoryId == R.id.familyFirstDegree) score += 3;
        else if (familyHistoryId == R.id.familyImmediate) score += 5;

        // Questão 8: Informado possuir a doença
        int doencaCardiId = doencaCardiGroup.getCheckedRadioButtonId();
        if (doencaCardiId == R.id.doencaCardiNo) score += 0;
        else if (doencaCardiId == R.id.doencaCardiYes) score += 3;

        // Questão 9: Medicamento
        int medicamentoId = medicamentoGroup.getCheckedRadioButtonId();
        if (medicamentoId == R.id.medicamentoNo) score += 0;
        else if (medicamentoId == R.id.medicamentoYes) score += 3;

        // Exibir o resultado
        String resultMessage = "Resultado final: " + score + " de 27 \n";
        if (score < 7) {
            resultMessage += "Baixo risco";
        } else if (score >= 8 && score <= 12) {
            resultMessage += "Risco levemente elevado";
        } else if (score >= 13 && score <= 17) {
            resultMessage += "Risco moderado";
        } else if (score >= 18 && score <= 22) {
            resultMessage += "Risco alto";
        } else if (score > 22) {
            resultMessage += "Risco muito alto";
        }

        showResultDialog(resultMessage);
    }

    private void showResultDialog(String resultMessage) {
        // Inflar o layout personalizado
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_result, null);

        // Inicializar os componentes do layout do dialog
        TextView resultTextView = dialogView.findViewById(R.id.tv_result_message);
        Button okButton = dialogView.findViewById(R.id.btn_ok);

        // Definir o texto do resultado
        resultTextView.setText(resultMessage);

        // Criar o AlertDialog
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setView(dialogView);

        // Criar o AlertDialog
        AlertDialog alertDialog = dialogBuilder.create();

        // Remover o fundo escuro
        if (alertDialog.getWindow() != null) {
            alertDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        // Exibir o AlertDialog
        alertDialog.show();

        // Ajustar a largura do AlertDialog
        if (alertDialog.getWindow() != null) {
            alertDialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.85), // largura 85% da tela
                    WindowManager.LayoutParams.WRAP_CONTENT); // altura ajustada automaticamente
        }

        // Listener para fechar o AlertDialog ao clicar no botão "OK"
        okButton.setOnClickListener(v -> alertDialog.dismiss());
    }
}