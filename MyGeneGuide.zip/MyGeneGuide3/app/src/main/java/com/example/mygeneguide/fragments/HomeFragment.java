package com.example.mygeneguide.fragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.navigation.NavController;
import androidx.navigation.NavOptions;
import androidx.navigation.Navigation;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import android.widget.TextView;
import android.util.Log;


import com.example.mygeneguide.R;
import com.google.firebase.database.annotations.Nullable;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.FirebaseFirestore;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private CardView btnExplicacao, btnQuestionarios, btnClinicas, btnPerfil;
    private TextView txtOlaUsuario; // Para exibir o nome do usuário
    private FirebaseFirestore db = FirebaseFirestore.getInstance();
    private String usuarioID;

    public HomeFragment() {
        // Required empty public constructor
    }

    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        IniciarComponentes(view);

        FirebaseAuth auth = FirebaseAuth.getInstance();
        if (auth.getCurrentUser() != null) {
            usuarioID = auth.getCurrentUser().getUid();
            recuperarNomeUsuario();
        }

        // Navegação entre fragments
        btnExplicacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegar para o fragment ExplicaFragment
                NavController navController = Navigation.findNavController(v);
                navController.navigate(R.id.menu_explica, null, new NavOptions.Builder().setPopUpTo(R.id.menu_home, true).build());
            }
        });

        btnQuestionarios.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegar para o fragment QuestioFragment
                NavController navController = Navigation.findNavController(v);
                navController.navigate(R.id.menu_questio, null, new NavOptions.Builder().setPopUpTo(R.id.menu_home, true).build());
            }
        });

        btnClinicas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegar para o fragment MapaFragment
                NavController navController = Navigation.findNavController(v);
                navController.navigate(R.id.menu_mapa, null, new NavOptions.Builder().setPopUpTo(R.id.menu_home, true).build());
            }
        });

        btnPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navegar para o fragment PerfilFragment
                NavController navController = Navigation.findNavController(v);
                navController.navigate(R.id.menu_perfil, null, new NavOptions.Builder().setPopUpTo(R.id.menu_home, true).build());
            }
        });

        return view;
    }

    private void recuperarNomeUsuario() {
        DocumentReference documentReference = db.collection("Usuarios").document(usuarioID);
        documentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Log.e("FirebaseError", error.getMessage());
                    return;
                }

                if (documentSnapshot != null && documentSnapshot.exists()) {
                    String nome = documentSnapshot.getString("nome");
                    txtOlaUsuario.setText(nome); // Atualizar o TextView com o nome
                } else {
                    Log.d("HomeFragment", "Usuário não encontrado.");
                }
            }
        });
    }

    private void IniciarComponentes(View view) {
        btnExplicacao = view.findViewById(R.id.btnExplicacao);
        btnQuestionarios = view.findViewById(R.id.btnQuestionarios);
        btnClinicas = view.findViewById(R.id.btnClinicas);
        btnPerfil = view.findViewById(R.id.btnPerfil);
        txtOlaUsuario = view.findViewById(R.id.txtOlaUsuario);
    }

}




