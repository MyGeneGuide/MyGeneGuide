package com.example.mygeneguide.fragments;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import com.example.mygeneguide.R;

public class MapaFragment extends Fragment {
    private CardView cardSL, cardB, cardS, cardMarcia, cardHSCS, cardMaria;
    private ImageView saoluiz, beneficiencia, santa, marcia, hospSCS, maria;
    private CheckBox hospParticular, hospSUS;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_mapa, container, false);

        cardSL = view.findViewById(R.id.cardSL);
        cardB = view.findViewById(R.id.cardB);
        cardS = view.findViewById(R.id.cardS);
        cardMarcia = view.findViewById(R.id.cardMarcia);
        cardHSCS = view.findViewById(R.id.cardHSCS);
        cardMaria = view.findViewById(R.id.cardMaria);

        saoluiz = view.findViewById(R.id.imgSaoLuiz);
        beneficiencia = view.findViewById(R.id.imgBeneficiencia);
        santa = view.findViewById(R.id.imgSanta);
        marcia = view.findViewById(R.id.imgMarciaBraido);
        hospSCS = view.findViewById(R.id.imgHospSCS);
        maria = view.findViewById(R.id.imgMaria);

        hospParticular = view.findViewById(R.id.hospParticular);
        hospParticular.setButtonTintList(ColorStateList.valueOf(Color.rgb(17, 62, 89)));
        hospSUS = view.findViewById(R.id.hospSUS);
        hospSUS.setButtonTintList(ColorStateList.valueOf(Color.rgb(17, 62, 89)));

        // Listener para Hospitais Particulares
        hospParticular.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                cardSL.setVisibility(View.VISIBLE);
                cardB.setVisibility(View.VISIBLE);
                cardS.setVisibility(View.VISIBLE);

                cardMarcia.setVisibility(View.GONE);
                cardHSCS.setVisibility(View.GONE);
                cardMaria.setVisibility(View.GONE);

                hospSUS.setChecked(false);
            } else if (!hospSUS.isChecked()) {
                showAllHospitals();
            }
        });

        // Listener para Hospitais Gratuitos
        hospSUS.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                cardMarcia.setVisibility(View.VISIBLE);
                cardHSCS.setVisibility(View.VISIBLE);
                cardMaria.setVisibility(View.VISIBLE);

                cardSL.setVisibility(View.GONE);
                cardB.setVisibility(View.GONE);
                cardS.setVisibility(View.GONE);

                hospParticular.setChecked(false);
            } else if (!hospParticular.isChecked()) {
                showAllHospitals();
            }
        });

        setupCardListeners();

        return view;
    }

    private void setupCardListeners() {
        cardSL.setOnClickListener(v -> openMap("https://www.google.com/maps/dir//Hospital+e+Maternidade+S%C3%A3o+Luiz+S%C3%A3o+Caetano:..."));
        saoluiz.setOnClickListener(v -> openMap("https://www.google.com/maps/dir//Hospital+e+Maternidade+S%C3%A3o+Luiz+S%C3%A3o+Caetano:..."));

        cardB.setOnClickListener(v -> openMap("https://www.google.com/maps/dir//Hospital+Benefic%C3%AAncia+Portuguesa+S%C3%A3o+Caetano+do+Sul:..."));
        beneficiencia.setOnClickListener(v -> openMap("https://www.google.com/maps/dir//Hospital+Benefic%C3%AAncia+Portuguesa+S%C3%A3o+Caetano+do+Sul:..."));

        cardS.setOnClickListener(v -> openMap("https://www.google.com/maps?daddr=R.+Cavalheiro+Ernesto+Giuliano,+979+-+S%C3%A3o+Jos%C3%A9,+S%C3%A3o+Caetano+do+Sul:..."));
        santa.setOnClickListener(v -> openMap("https://www.google.com/maps?daddr=R.+Cavalheiro+Ernesto+Giuliano,+979+-+S%C3%A3o+Jos%C3%A9,+S%C3%A3o+Caetano+do+Sul:..."));

        cardMarcia.setOnClickListener(v -> openMap("https://www.google.com/maps/dir//Complexo+Hospitalar+de+Cl%C3%ADnicas+-+Bloco+C+M%C3%A1rcia+Braido:..."));
        marcia.setOnClickListener(v -> openMap("https://www.google.com/maps/dir//Complexo+Hospitalar+de+Cl%C3%ADnicas+-+Bloco+C+M%C3%A1rcia+Braido:..."));

        cardHSCS.setOnClickListener(v -> openMap("https://www.google.com/maps/dir//Hospital+S%C3%A3o+Caetano:..."));
        hospSCS.setOnClickListener(v -> openMap("https://www.google.com/maps/dir//Hospital+S%C3%A3o+Caetano:..."));

        cardMaria.setOnClickListener(v -> openMap("https://www.google.com/maps/dir//R.+S%C3%A3o+Paulo,+1840+-+Santa+Paula,+S%C3%A3o+Caetano+do+Sul:..."));
        maria.setOnClickListener(v -> openMap("https://www.google.com/maps/dir//R.+S%C3%A3o+Paulo,+1840+-+Santa+Paula,+S%C3%A3o+Caetano+do+Sul:..."));
    }

    private void openMap(String url) {
        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
    }

    private void showAllHospitals() {
        cardSL.setVisibility(View.VISIBLE);
        cardB.setVisibility(View.VISIBLE);
        cardS.setVisibility(View.VISIBLE);
        cardMarcia.setVisibility(View.VISIBLE);
        cardHSCS.setVisibility(View.VISIBLE);
        cardMaria.setVisibility(View.VISIBLE);
    }
}
