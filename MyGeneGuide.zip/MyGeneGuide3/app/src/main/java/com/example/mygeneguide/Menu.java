package com.example.mygeneguide;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.NavigationUI;
import androidx.navigation.Navigation;

import com.example.mygeneguide.databinding.ActivityMenuBinding;

public class Menu extends AppCompatActivity {
    private ActivityMenuBinding binding;
    private NavHostFragment navHostFragment;
    private NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        binding = ActivityMenuBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initNavigation();
    }

    // Corrigir o método onBackPressed, movendo-o para fora do onCreate
    @Override
    public void onBackPressed() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);

        // Verifica se o usuário não está no fragmento Home
        if (navController.getCurrentDestination().getId() != R.id.menu_home) {
            // Se não estiver no HomeFragment, navega de volta para o HomeFragment
            navController.navigate(R.id.menu_home);
        } else {
            // Caso contrário, execute o comportamento padrão do botão de voltar
            super.onBackPressed();
        }
    }

    private void initNavigation(){
        navHostFragment = (NavHostFragment) getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment);
        navController   = navHostFragment.getNavController();

        NavigationUI.setupWithNavController(binding.bottomNavigation, navController);
    }
}
