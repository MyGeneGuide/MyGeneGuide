package com.example.mygeneguide;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.mygeneguide.fragments.QuestioFragment;

public class Questionario_Cardio extends AppCompatActivity {

    RadioGroup cansacoGroup, physicalActivityGroup, inchacoGroup, TonturaGroup, palpitacaoGroup, smokerGroup, familyHistoryGroup, imcgroup;
    Button calculateButton, cancelButton;
    TextView txtTotalIMC;
    CardView btnCalcularIMC;
    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_questionario_cardio);

        cansacoGroup = findViewById(R.id.cansacoGroup);
        physicalActivityGroup = findViewById(R.id.physicalActivityGroup);
        inchacoGroup = findViewById(R.id.inchacoGroup);
        TonturaGroup = findViewById(R.id.TonturaGroup);
        palpitacaoGroup = findViewById(R.id.palpitacaoGroup);
        smokerGroup = findViewById(R.id.smokerGroup);
        familyHistoryGroup = findViewById(R.id.familyHistoryGroup);
        imcgroup = findViewById(R.id.imcgroup);

        calculateButton = findViewById(R.id.calculateButton);
        cancelButton = findViewById(R.id.cancelButton);
        btnCalcularIMC = findViewById(R.id.btnCalcularIMC);
        txtTotalIMC = findViewById(R.id.txtTotalIMC);

        // Listener do botão para calcular o risco
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateRisk();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplication(), QuestioFragment.class);
                startActivity(intent);
                finish();
            }
        });

        // Listener do botão para abrir o diálogo de cálculo de IMC
        btnCalcularIMC.setOnClickListener(v -> showIMCCalculatorDialog());
    }
    private void showIMCCalculatorDialog() {
        // Inflate o layout do diálogo personalizado
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_calculo_imc, null);

        // Inicialize os campos do diálogo
        EditText inputWeight = dialogView.findViewById(R.id.input_weight);
        EditText inputHeight = dialogView.findViewById(R.id.input_height);
        TextView txtResultadoIMC = dialogView.findViewById(R.id.txtResultadoIMC);

        ImageView btnCloseAlert = dialogView.findViewById(R.id.btn_closeAlert); // Botão de fechar

        // Cria o AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);
        builder.setCancelable(true);

        AlertDialog dialog = builder.create();

        // Configura o botão Salvar
        Button btnSave = dialogView.findViewById(R.id.btn_save);
        btnSave.setOnClickListener(v -> {
            // Pega os valores de peso e altura
            String weightStr = inputWeight.getText().toString();
            String heightStr = inputHeight.getText().toString();

            if (!weightStr.isEmpty() && !heightStr.isEmpty()) {
                double weight = Double.parseDouble(weightStr);
                double height = Double.parseDouble(heightStr) / 100; // Converte cm para metros

                // Calcula o IMC
                double imc = weight / (height * height);
                String imcResult;

                // Classificação do IMC
                if (imc < 18.5) {
                    imcResult = "Baixo peso";
                } else if (imc < 25) {
                    imcResult = "Normal ou Eutrófico";
                } else if (imc < 30) {
                    imcResult = "Sobrepeso";
                } else if (imc < 35) {
                    imcResult = "Obesidade I";
                } else if (imc < 40) {
                    imcResult = "Obesidade II";
                } else {
                    imcResult = "Obesidade III";
                }

                // Exibe o resultado do IMC
                txtResultadoIMC.setText(String.format("IMC: %.2f - %s", imc, imcResult));

                txtTotalIMC.setVisibility(View.VISIBLE);
                txtTotalIMC.setText(String.format("IMC: %.2f - %s", imc, imcResult));
            } else {
                txtResultadoIMC.setText("Por favor, insira peso e altura");
            }

        });

        // Configura o botão de fechar para encerrar o diálogo
        btnCloseAlert.setOnClickListener(v -> dialog.dismiss());

        // Exibe o diálogo
        dialog.show();
    }
    private void calculateRisk() {
        score = 0;  // Resetar o score

        // Verificar qual opção foi selecionada para cada pergunta e somar o score correspondente

        // Questão 1: Idade
        int pressaoId = cansacoGroup.getCheckedRadioButtonId();
        if (pressaoId == R.id.cansacoNo) score += 0;
        else if (pressaoId == R.id.cansacoYes) score += 3;

        // Questão 2: Atividade Física
        int physicalActivityId = physicalActivityGroup.getCheckedRadioButtonId();
        if (physicalActivityId == R.id.physicalYes) score += 0;
        else if (physicalActivityId == R.id.physicalNo) score += 2;

        // Questão 3: Alimentação
        int inchacoId = inchacoGroup.getCheckedRadioButtonId();
        if (inchacoId == R.id.inchacoNo) score += 0;
        else if (inchacoId == R.id.inchacoYes) score += 3;

        // Questão 4: Medicação para pressão alta
        int tonturaId = TonturaGroup.getCheckedRadioButtonId();
        if (tonturaId == R.id.tonturaYes) score += 0;
        else if (tonturaId == R.id.tonturaNo) score += 4;

        // Questão 5: Glicemia alta
        int palpitacaoId = palpitacaoGroup.getCheckedRadioButtonId();
        if (palpitacaoId == R.id.palpitacaoNo) score += 0;
        else if (palpitacaoId == R.id.palpitacaoYes) score += 4;

        // Questão 6: Fumante
        int smokerId = smokerGroup.getCheckedRadioButtonId();
        if (smokerId == R.id.smokerNo) score += 0;
        else if (smokerId == R.id.smokerYes) score += 2;

        // Questão 7: Histórico familiar de diabetes
        int familyHistoryId = familyHistoryGroup.getCheckedRadioButtonId();
        if (familyHistoryId == R.id.familyNo) score += 0;
        else if (familyHistoryId == R.id.familyFirstDegree) score += 3;
        else if (familyHistoryId == R.id.familyImmediate) score += 5;

        // Questão 8: IMC
        int imcgroupId = imcgroup.getCheckedRadioButtonId();
        if (imcgroupId == R.id.imcBelow25) score += 1;
        else if (imcgroupId == R.id.imc25to30) score += 2;
        else if (imcgroupId == R.id.imcAbove30) score += 4;

        // Exibir o resultado
        String resultMessage = "Resultado final: " + score + " de 27 \n";
        if (score < 5) {
            resultMessage += "Baixo risco";
        } else if (score >= 6 && score <= 10) {
            resultMessage += "Risco levemente elevado";
        } else if (score >= 11 && score <= 15) {
            resultMessage += "Risco moderado";
        } else if (score >= 16 && score <= 20) {
            resultMessage += "Risco alto";
        } else if (score > 21) {
            resultMessage += "Risco muito alto";
        }

        // Exibir o resultado em um AlertDialog
        showResultDialog(resultMessage);
    }
    private void showResultDialog(String resultMessage) {
        // Inflar o layout personalizado
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_result, null);

        // Inicializar os componentes do layout do dialog
        TextView resultTextView = dialogView.findViewById(R.id.tv_result_message);
        Button okButton = dialogView.findViewById(R.id.btn_ok);

        // Definir o texto do resultado
        resultTextView.setText(resultMessage);

        // Criar o AlertDialog
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setView(dialogView);

        // Criar o AlertDialog
        AlertDialog alertDialog = dialogBuilder.create();

        // Remover o fundo escuro
        if (alertDialog.getWindow() != null) {
            alertDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        // Exibir o AlertDialog
        alertDialog.show();

        // Ajustar a largura do AlertDialog
        if (alertDialog.getWindow() != null) {
            alertDialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.85), // largura 85% da tela
                    WindowManager.LayoutParams.WRAP_CONTENT); // altura ajustada automaticamente
        }

        // Listener para fechar o AlertDialog ao clicar no botão "OK"
        okButton.setOnClickListener(v -> alertDialog.dismiss());
    }
}
