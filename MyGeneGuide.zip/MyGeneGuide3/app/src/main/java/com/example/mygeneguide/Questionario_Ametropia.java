package com.example.mygeneguide;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.mygeneguide.fragments.QuestioFragment;

public class Questionario_Ametropia extends AppCompatActivity {

    RadioGroup ageGroup, dorCabecaGroup, ApertarOlhosGroup, horasGroup, visaoEmbacadaGroup, familyHistoryGroup, borroesGroup, alergiaGroup;
    Button calculateButton, cancelButton;
    int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_questionario_ametropia);
        ageGroup = findViewById(R.id.ageGroup);
        dorCabecaGroup = findViewById(R.id.dorCabecaGroup);
        ApertarOlhosGroup = findViewById(R.id.ApertarOlhosGroup);
        horasGroup = findViewById(R.id.horasGroup);
        visaoEmbacadaGroup = findViewById(R.id.visaoEmbacadaGroup);
        familyHistoryGroup = findViewById(R.id.familyHistoryGroup);
        borroesGroup = findViewById(R.id.borroesGroup);
        alergiaGroup = findViewById(R.id.alergiaGroup);

        calculateButton = findViewById(R.id.calculateButton);
        cancelButton = findViewById(R.id.cancelButton);

        // Listener do botão para calcular o risco
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculateRisk();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplication(), QuestioFragment.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void calculateRisk() {
        score = 0;  // Resetar o score

        // Verificar qual opção foi selecionada para cada pergunta e somar o score correspondente

        // Questão 1: Idade
        int ageId = ageGroup.getCheckedRadioButtonId();
        if (ageId == R.id.ageBelow20) score += 1;
        else if (ageId == R.id.age21to39) score += 3;
        else if (ageId == R.id.age40to60) score += 4;
        else if (ageId == R.id.ageAbove61) score += 5;

        // Questão 2: Atividade Física
        int dorCabecaId = dorCabecaGroup.getCheckedRadioButtonId();
        if (dorCabecaId == R.id.dorCabecaYes) score += 2;
        else if (dorCabecaId == R.id.dorCabecaNo) score += 0;

        // Questão 3: Alimentação
        int ApertarOlhosId = ApertarOlhosGroup.getCheckedRadioButtonId();
        if (ApertarOlhosId == R.id.ApertarOlhosNo) score += 0;
        else if (ApertarOlhosId == R.id.ApertarOlhosYes) score += 3;

        // Questão 4: Medicação para pressão alta
        int horasId = horasGroup.getCheckedRadioButtonId();
        if (horasId == R.id.horas2) score += 1;
        else if (horasId == R.id.horas4) score += 2;
        else if (horasId == R.id.horas8) score += 4;

        // Questão 5: Glicemia alta
        int visaoEmbacadaId = visaoEmbacadaGroup.getCheckedRadioButtonId();
        if (visaoEmbacadaId == R.id.visaoEmbacadaNo) score += 0;
        else if (visaoEmbacadaId == R.id.visaoEmbacadaYes) score += 4;

        // Questão 6: Histórico familiar de diabetes
        int familyHistoryId = familyHistoryGroup.getCheckedRadioButtonId();
        if (familyHistoryId == R.id.familyNo) score += 0;
        else if (familyHistoryId == R.id.familyFirstDegree) score += 3;
        else if (familyHistoryId == R.id.familyImmediate) score += 5;

        // Questão 7: Borroes
        int borroesId = borroesGroup.getCheckedRadioButtonId();
        if (borroesId == R.id.borroesNo) score += 0;
        else if (borroesId == R.id.borroesYes) score += 4;

        // Questão 8: Alergia
        int alergiaId = alergiaGroup.getCheckedRadioButtonId();
        if (alergiaId == R.id.alergiaNo) score += 0;
        else if (alergiaId == R.id.alergiaYes) score += 3;

        // Exibir o resultado
        String resultMessage = "Resultado final: " + score + " de 30 \n";
        if (score < 7) {
            resultMessage += "Baixo risco";
        } else if (score >= 8 && score <= 11) {
            resultMessage += "Risco levemente elevado";
        } else if (score >= 12 && score <= 15) {
            resultMessage += "Risco moderado";
        } else if (score >= 16 && score <= 20) {
            resultMessage += "Risco alto";
        } else if (score > 20) {
            resultMessage += "Risco muito alto";
        }

        // Exibir o resultado em um AlertDialog
        showResultDialog(resultMessage);
    }
    private void showResultDialog(String resultMessage) {
        // Inflar o layout personalizado
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_result, null);

        // Inicializar os componentes do layout do dialog
        TextView resultTextView = dialogView.findViewById(R.id.tv_result_message);
        Button okButton = dialogView.findViewById(R.id.btn_ok);

        // Definir o texto do resultado
        resultTextView.setText(resultMessage);

        // Criar o AlertDialog
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setView(dialogView);

        // Criar o AlertDialog
        AlertDialog alertDialog = dialogBuilder.create();

        // Remover o fundo escuro
        if (alertDialog.getWindow() != null) {
            alertDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        }

        // Exibir o AlertDialog
        alertDialog.show();

        // Ajustar a largura do AlertDialog
        if (alertDialog.getWindow() != null) {
            alertDialog.getWindow().setLayout((int) (getResources().getDisplayMetrics().widthPixels * 0.85), // largura 85% da tela
                    WindowManager.LayoutParams.WRAP_CONTENT); // altura ajustada automaticamente
        }

        // Listener para fechar o AlertDialog ao clicar no botão "OK"
        okButton.setOnClickListener(v -> alertDialog.dismiss());
    }
}