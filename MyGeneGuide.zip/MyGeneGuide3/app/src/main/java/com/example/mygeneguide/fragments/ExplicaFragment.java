package com.example.mygeneguide.fragments;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;

import com.example.mygeneguide.R;

public class ExplicaFragment extends Fragment {

    private TextView explicacaoDText, explicacaoCText, explicacaoRText, explicacaoAText;
    private LinearLayout layoutD, layoutC, layoutR, layoutA;

    public ExplicaFragment() {
        // Construtor vazio
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflar o layout para este fragmento. Verifique se este é o layout correto.
        View view = inflater.inflate(R.layout.fragment_explica, container, false);

        try {
            // Inicializando as views
            explicacaoDText = view.findViewById(R.id.explicacaoD);
            layoutD = view.findViewById(R.id.layoutD);
            // Removendo temporariamente as transições
            // layoutD.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);

            explicacaoCText = view.findViewById(R.id.explicacaoC);
            layoutC = view.findViewById(R.id.layoutC);
            // layoutC.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);

            explicacaoRText = view.findViewById(R.id.explicacaoR);
            layoutR = view.findViewById(R.id.layoutR);
            // layoutR.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);

            explicacaoAText = view.findViewById(R.id.explicacaoA);
            layoutA = view.findViewById(R.id.layoutA);
            // layoutA.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING);

            // Configurando os listeners para expandir ou recolher as explicações diretamente nos layouts
            layoutD.setOnClickListener(v -> expand(explicacaoDText));
            layoutC.setOnClickListener(v -> expand(explicacaoCText));
            layoutR.setOnClickListener(v -> expand(explicacaoRText));
            layoutA.setOnClickListener(v -> expand(explicacaoAText));

        } catch (NullPointerException e) {
            // Verificar se as views existem e o layout está correto
            e.printStackTrace();
        }

        return view;
    }

    // Função de expandir/recolher sem as transições
    private void expand(TextView textView) {
        int visibility = (textView.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE;
        textView.setVisibility(visibility);
    }
}
